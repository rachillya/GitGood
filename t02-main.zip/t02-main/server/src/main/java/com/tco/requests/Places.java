package com.tco.requests;
import java.util.ArrayList;

public class Places extends ArrayList<Place> {
}
