package com.tco.requests;

import java.util.ArrayList;

public class Distances extends ArrayList<Long> {
}