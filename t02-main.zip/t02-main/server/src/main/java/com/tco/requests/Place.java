package com.tco.requests;

import java.util.HashMap;

public class Place extends HashMap<String,String> {
    
}
