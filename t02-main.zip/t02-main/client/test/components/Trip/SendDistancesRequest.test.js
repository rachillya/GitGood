import React from 'react';
import {render, screen, waitFor} from '@testing-library/react';
import '@testing-library/jest-dom';
import user from '@testing-library/user-event';
import { beforeEach, describe, expect, it, jest } from '@jest/globals';
import SendDistancesRequest from "../../../src/components/Trip/Itinerary/SendDistancesRequest";
import {MOCK_PLACES} from "../../sharedMocks";

describe('Distances Request', () => {

    beforeEach(() => {

    });

    it('renames latitude and longitude in place', async () => {

    });

    it('sums the distances', async () => {

    });

});